# Benefit Illustration — redesigned starter

A redesigned Angular + Express demo. The visual design intentionally differs from the reference screenshot.

## Start backend
```powershell
cd backend
npm install
npm run dev
```
Backend: http://localhost:5000

## Start frontend (second terminal)
```powershell
cd frontend
npm install
npm start
```
Frontend: http://localhost:4200

## Important calculation assumptions
- Premium per instalment validated from ₹10,000 to ₹50,000.
- Annual premium = instalment premium × frequency multiplier (1, 2, or 12).
- PT: 10–20; PPT: 5–10; PT must exceed PPT.
- Entry age: 23–56.
- Sum assured: at least 10× annual premium and between ₹5,00,000 and ₹50,00,000.
- Bonus rates are copied from the supplied 20-year schedule.
- The sample ₹80,000 premium conflicts with the supplied ₹50,000 maximum. Default value is ₹40,000.
- Maturity and IRR are prototype calculations and must be reconciled with the original spreadsheet before being treated as accurate.
