const BONUS_RATES = [0.025,0.03,0.035,0.035,0.035,0.035,0.03,0.03,0.03,0.03,0.03,0.025,0.03,0.03,0.025,0.05,0.04,0.045,0.04,0.25];
function ageOnDate(value) {
  const d = new Date(value + 'T00:00:00');
  if (Number.isNaN(d.getTime())) return NaN;
  const now = new Date();
  return now.getFullYear() - d.getFullYear() - ((now.getMonth() < d.getMonth() || (now.getMonth() === d.getMonth() && now.getDate() < d.getDate())) ? 1 : 0);
}
function validateInputs(x) {
  const e = [], premium = Number(x.premiumPerInstalment), sa = Number(x.sumAssured), pt = Number(x.policyTerm), ppt = Number(x.premiumPayingTerm);
  const freq = { yearly: 1, 'half-yearly': 2, monthly: 12 };
  if (!x.dateOfBirth || !Number.isFinite(ageOnDate(x.dateOfBirth))) e.push('Enter a valid date of birth.');
  else if (ageOnDate(x.dateOfBirth) < 23 || ageOnDate(x.dateOfBirth) > 56) e.push('Entry age must be between 23 and 56.');
  if (!['M','F','O'].includes(x.gender)) e.push('Choose a gender.');
  if (!Number.isFinite(premium) || premium < 10000 || premium > 50000) e.push('Premium per instalment must be ₹10,000–₹50,000.');
  if (!freq[x.premiumFrequency]) e.push('Choose a premium frequency.');
  if (!Number.isInteger(pt) || pt < 10 || pt > 20) e.push('Policy term must be 10–20 years.');
  if (!Number.isInteger(ppt) || ppt < 5 || ppt > 10) e.push('Premium-paying term must be 5–10 years.');
  if (Number.isInteger(pt) && Number.isInteger(ppt) && pt <= ppt) e.push('Policy term must be greater than premium-paying term.');
  if (Number.isFinite(premium) && freq[x.premiumFrequency] && (!Number.isFinite(sa) || sa < premium * freq[x.premiumFrequency] * 10)) e.push('Sum assured must be at least 10× annual premium.');
  if (!Number.isFinite(sa) || sa < 500000 || sa > 5000000) e.push('Sum assured must be ₹5,00,000–₹50,00,000.');
  return e;
}
function irr(cfs) {
  const npv = r => cfs.reduce((s, v, t) => s + v / Math.pow(1 + r, t), 0);
  let lo = -0.9999, hi = 10, fl = npv(lo), fh = npv(hi);
  if (!Number.isFinite(fl) || !Number.isFinite(fh) || fl * fh > 0) return null;
  for (let i = 0; i < 250; i++) { const m = (lo + hi) / 2, fm = npv(m); if (Math.abs(fm) < 1e-7) return m; if (fl * fm <= 0) { hi = m; fh = fm; } else { lo = m; fl = fm; } }
  return (lo + hi) / 2;
}
function generateIllustration(x) {
  const multiplier = { yearly: 1, 'half-yearly': 2, monthly: 12 }[x.premiumFrequency];
  const annualPremium = Number(x.premiumPerInstalment) * multiplier, sa = Number(x.sumAssured), pt = Number(x.policyTerm), ppt = Number(x.premiumPayingTerm);
  const bonusTotal = BONUS_RATES.slice(0, pt).reduce((sum, rate) => sum + sa * rate, 0);
  const rows = [], cfs = [0];
  for (let year = 1; year <= pt; year++) {
    const premium = year <= ppt ? annualPremium : 0, bonusRate = BONUS_RATES[year - 1] || 0;
    const bonusAmount = sa * bonusRate, totalBenefit = year === pt ? sa + bonusTotal : 0, netCashFlow = totalBenefit - premium;
    rows.push({ policyYear: year, premium, sumAssured: year === pt ? sa : 0, bonusRate, bonusAmount, totalBenefit, netCashFlow });
    cfs.push(netCashFlow);
  }
  const rate = irr(cfs);
  return { entryAge: ageOnDate(x.dateOfBirth), annualPremium, totalPremiumPaid: annualPremium * ppt, policyTerm: pt, premiumPayingTerm: ppt, maturityBenefit: sa + bonusTotal, irr: rate === null ? null : rate * 100, rows, assumptions: ['Bonus rates use the supplied 20-year schedule.', 'Maturity includes bonuses only through the selected policy term.', 'IRR assumes annual year-end cash flows; verify against the workbook.'] };
}
module.exports = { validateInputs, generateIllustration };
