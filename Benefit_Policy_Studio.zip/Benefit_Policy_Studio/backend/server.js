const express = require('express');
const cors = require('cors');
const { validateInputs, generateIllustration } = require('./src/illustration');
const app = express();
app.use(cors());
app.use(express.json());
app.get('/api/health', (_req, res) => res.json({ success: true }));
app.post('/api/illustrations/generate', (req, res) => {
  const errors = validateInputs(req.body);
  if (errors.length) return res.status(400).json({ success: false, errors });
  try { res.json({ success: true, data: generateIllustration(req.body) }); }
  catch { res.status(500).json({ success: false, errors: ['Unable to calculate illustration.'] }); }
});
app.listen(process.env.PORT || 5000, () => console.log('Benefit API running on port ' + (process.env.PORT || 5000)));
